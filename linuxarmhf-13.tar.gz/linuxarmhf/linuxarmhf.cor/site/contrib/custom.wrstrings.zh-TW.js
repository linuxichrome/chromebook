(function ($) {
    $.localization.customStringBundle('zh-TW', {
        Example1: 'This is an example',
        Example2: 'This is another example',
        RefreshApps: 'TRANSLATE-Refresh Apps',
        Preferences: 'TRANSLATE-Preferences...',
        ConnCenter: 'TRANSLATE-Connection Center',
        About: 'TRANSLATE-About'
    });
})(jQuery);
