(function ($) {
    $.localization.customStringBundle('ja', {
        Example1: 'This is an example',
        Example2: 'This is another example',
        RefreshApps: 'アプリ一覧の更新',
        Accounts: 'アカウント',
        Preferences: '環境設定...',
        ConnCenter: 'コネクション センター',
        About: 'バージョン情報'
    });
})(jQuery);
