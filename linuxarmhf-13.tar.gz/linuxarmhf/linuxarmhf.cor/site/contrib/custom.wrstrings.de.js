(function ($) {
    $.localization.customStringBundle('de', {
        Example1: 'Beispiel',
        Example2: 'Weiteres Beispiel',
        RefreshApps: 'Apps aktualisieren',
        Accounts: 'Konten',
        Preferences: 'Einstellungen...',
        ConnCenter: 'Connection Center',
        About: 'Info'
    });
})(jQuery);
