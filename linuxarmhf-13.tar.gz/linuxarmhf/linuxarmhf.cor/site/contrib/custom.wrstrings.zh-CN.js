(function ($) {
    $.localization.customStringBundle('zh-CN', {
        Example1: '这是一个示例',
        Example2: '这是另一个示例',
        RefreshApps: '刷新应用程序',
        Accounts: '帐户',
        Preferences: '首选项...',
        ConnCenter: '连接中心',
        About: '关于'
    });
})(jQuery);
