(function ($) {
    $.localization.customStringBundle('en', {
        Example1: 'This is an example',
        Example2: 'This is another example',
        RefreshApps: 'Refresh Apps',
        Accounts: 'Accounts',
        Preferences: 'Preferences...',
        ConnCenter: 'Connection Center',
        About: 'About'
    });
})(jQuery);
